package poly.lab5.servlet;

import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import poly.lab5.model.Staff;

@WebServlet("/save")
public class SaveServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {

        req.setCharacterEncoding("UTF-8");
        resp.setCharacterEncoding("UTF-8");

        // mở trang form
        req.getRequestDispatcher("/views/staff-form.jsp").forward(req, resp);
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {

        req.setCharacterEncoding("UTF-8");
        resp.setCharacterEncoding("UTF-8");

        Staff bean = new Staff();

        // ---- TỰ ĐỌC FORM, KHÔNG DÙNG BEANUTILS ----
        bean.setFullname(req.getParameter("fullname"));

        String dateStr = req.getParameter("birthday");
        try {
            bean.setBirthday(new SimpleDateFormat("MM/dd/yyyy").parse(dateStr));
        } catch (ParseException e) {
            e.printStackTrace();
        }

        String genderStr = req.getParameter("gender");
        bean.setGender("true".equals(genderStr));

        bean.setHobbies(req.getParameterValues("hobbies"));

        bean.setCountry(req.getParameter("country"));

        try {
            bean.setSalary(Double.parseDouble(req.getParameter("salary")));
        } catch (Exception e) {
            bean.setSalary(0);
        }
        // -------------------------------------------

        System.out.println(bean);
        req.setAttribute("staff", bean);

        req.getRequestDispatcher("/views/staff-form.jsp").forward(req, resp);
    }
}
