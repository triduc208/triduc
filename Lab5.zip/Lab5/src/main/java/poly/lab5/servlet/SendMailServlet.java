package poly.lab5.servlet;

import java.io.IOException;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import javax.mail.MessagingException;

import poly.lab5.utils.Mailer;

@WebServlet("/send-mail")
public class SendMailServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {

        req.setCharacterEncoding("UTF-8");
        resp.setCharacterEncoding("UTF-8");

        req.getRequestDispatcher("/views/send-mail.jsp").forward(req, resp);
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {

        req.setCharacterEncoding("UTF-8");
        resp.setCharacterEncoding("UTF-8");

        String from = req.getParameter("from");
        String to = req.getParameter("to");
        String subject = req.getParameter("subject");
        String body = req.getParameter("body");

        try {
            Mailer.send(from, to, subject, body);
            req.setAttribute("message", "Gửi mail thành công!");
        } catch (MessagingException e) {
            e.printStackTrace();
            req.setAttribute("error", "Gửi mail thất bại: " + e.getMessage());
        }

        req.getRequestDispatcher("/views/send-mail.jsp").forward(req, resp);
    }
}
