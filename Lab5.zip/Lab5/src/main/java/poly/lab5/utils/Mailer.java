package poly.lab5.utils;

import java.util.Properties;

import javax.mail.Authenticator;
import javax.mail.Message.RecipientType;
import javax.mail.MessagingException;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

public class Mailer {

    public static void send(String from, String to, String subject, String body)
            throws MessagingException {

        // cấu hình SMTP Gmail
    	Properties props = new Properties();
    	props.put("mail.smtp.auth", "true");
    	props.put("mail.smtp.starttls.enable", "true");
    	props.put("mail.smtp.starttls.required", "true");
    	props.put("mail.smtp.host", "smtp.gmail.com");
    	props.put("mail.smtp.port", "587");
    	props.put("mail.smtp.ssl.protocols", "TLSv1.2");
    	props.put("mail.smtp.ssl.trust", "smtp.gmail.com");


        // Tài khoản GMAIL dùng để gửi
        final String username = "ducntts02225@gmail.com";   // <-- SỬA LẠI
        final String password = "kqudwpyekgthhlss";      // <-- SỬA LẠI (app password)

        Session session = Session.getInstance(props, new Authenticator() {
            @Override
            protected PasswordAuthentication getPasswordAuthentication() {
                return new PasswordAuthentication(username, password);
            }
        });

        MimeMessage mail = new MimeMessage(session);
        mail.setFrom(new InternetAddress(from));
        mail.setRecipients(RecipientType.TO, to);
        mail.setSubject(subject, "UTF-8");
        mail.setText(body, "UTF-8", "html");
        mail.setReplyTo(mail.getFrom());

        Transport.send(mail);
    }
}
