package test;

import java.sql.Connection;
import java.sql.SQLException;

import utils.DBConnect;

public class TestDBLab6 {
    public static void main(String[] args) {
        try (Connection con = DBConnect.getConnection()) {
            System.out.println("Kết nối database thành công (Lab6)!");
        } catch (SQLException e) {
            System.out.println("Lỗi kết nối DB: " + e.getMessage());
        }
    }
}
