package utils;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DBConnect {

    private static final String URL =
        "jdbc:sqlserver://localhost:1433;databaseName=ABCNews;encrypt=false";
    private static final String USER = "sa";  // user SQL Server của m
    private static final String PASS = "";    // pass nếu m đang để trống

    // load driver 1 lần khi class được load
    static {
        try {
            Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
            System.out.println("Loaded SQL Server JDBC Driver");
        } catch (ClassNotFoundException e) {
            System.err.println("Không tìm thấy driver SQL Server:");
            e.printStackTrace();
        }
    }

    public static Connection getConnection() throws SQLException {
        return DriverManager.getConnection(URL, USER, PASS);
    }
}
