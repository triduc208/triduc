package poly.com.controller;

import java.io.IOException;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet(name = "Bai3controller",
           urlPatterns = {"/crud/them", "/crud/xoa", "/crud/sua"})
public class Bai3controller extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {
        handle(req, resp);
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {
        handle(req, resp);
    }

    private void handle(HttpServletRequest req, HttpServletResponse resp)
            throws IOException {
        resp.setContentType("text/html;charset=UTF-8");
        String path = req.getServletPath(); 

        switch (path) {
            case "/crud/them":
                resp.getWriter().println("<h1>Creating a new record...</h1>");
                break;
            case "/crud/xoa":
                resp.getWriter().println("<h1>Xóa dữ liệu...</h1>");
                break;
            case "/crud/sua":
                resp.getWriter().println("<h1>Sửa dữ liệu...</h1>");
                break;
            default:
                resp.getWriter().println("<h1>Unknown action</h1>");
        }
    }
}
